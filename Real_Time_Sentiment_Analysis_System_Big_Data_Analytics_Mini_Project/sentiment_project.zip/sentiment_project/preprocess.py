"""
preprocess.py  -  shared text-cleaning module
---------------------------------------------
The SAME function is used in:
  * the Colab notebook (training, Kafka consumer, Spark)
  * the Streamlit dashboard (live predictions)
Using one function everywhere guarantees that training data and new
posts are cleaned in exactly the same way.
"""
import re
import html
from functools import lru_cache

import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import TweetTokenizer

# ---- one-time NLTK resource download (quiet, safe to call many times) ----
for _res in ("stopwords", "wordnet", "omw-1.4"):
    try:
        nltk.download(_res, quiet=True)
    except Exception:
        pass

# ---- regular expressions (compiled once for speed) ----
URL_RE      = re.compile(r"https?://\S+|www\.\S+")
MENTION_RE  = re.compile(r"@\w+")
HASHTAG_RE  = re.compile(r"#(\w+)")
NON_ALPHA   = re.compile(r"[^a-z\s]")
MULTISPACE  = re.compile(r"\s+")

# ---- stop words: keep negations, they flip the meaning of a sentence ----
# "not good" and "good" are opposite sentiments, so we must NOT delete "not".
_NEGATIONS = {"no", "nor", "not", "never", "none", "nothing", "neither", "cannot"}
STOP_WORDS = set(stopwords.words("english")) - _NEGATIONS
# very short leftovers created by contractions ("it's" -> "it s")
STOP_WORDS |= {"amp", "rt", "via"}

_tokenizer  = TweetTokenizer(preserve_case=False, strip_handles=True, reduce_len=True)
_lemmatizer = WordNetLemmatizer()

# WordNet occasionally mangles a word ("scared" -> "scar", "pass" -> "pas").
# "scared" is an important negative-emotion word, so we protect it.
_LEMMA_EXCEPTIONS = {"scared": "scared", "pass": "pass"}


@lru_cache(maxsize=200_000)
def _lemma(word: str) -> str:
    """Lemmatize a word (cached, because the same words repeat a lot).
    First as a noun (prices -> price), then as a verb (buying -> buy)."""
    if word in _LEMMA_EXCEPTIONS:
        return _LEMMA_EXCEPTIONS[word]
    return _lemmatizer.lemmatize(_lemmatizer.lemmatize(word), pos="v")


def extract_hashtags(text: str):
    """Return the list of lower-case hashtags of a raw post (without '#')."""
    return [h.lower() for h in HASHTAG_RE.findall(str(text))]


def preprocess_text(text: str, return_tokens: bool = False):
    """
    Full cleaning pipeline for one social media post.

    1. lower-case + decode HTML entities (&amp; -> &)
    2. remove URLs and @mentions
    3. keep the WORD of a hashtag (#lockdown -> lockdown)
    4. expand contractions (don't -> do not)
    5. remove special characters, digits, emojis
    6. tokenize
    7. remove stop words (but keep negations)
    8. lemmatize
    """
    if not isinstance(text, str):
        return [] if return_tokens else ""

    text = html.unescape(text).lower()
    text = text.replace("\u2019", "'").replace("\u2018", "'")   # curly quotes
    text = URL_RE.sub(" ", text)
    text = MENTION_RE.sub(" ", text)
    text = HASHTAG_RE.sub(r"\1", text)

    text = re.sub(r"\bwon't\b", "will not", text)
    text = re.sub(r"\bcan't\b", "can not", text)
    text = re.sub(r"n't\b", " not", text)

    text = NON_ALPHA.sub(" ", text)
    text = MULTISPACE.sub(" ", text).strip()

    tokens = _tokenizer.tokenize(text)
    tokens = [t for t in tokens if len(t) > 1 and t not in STOP_WORDS]
    tokens = [_lemma(t) for t in tokens]

    return tokens if return_tokens else " ".join(tokens)
