# Streamlit dashboard - run with:  streamlit run streamlit_app.py
# It only reads the files that the notebook saved in the "artifacts" folder.
import json
from pathlib import Path
import joblib
import matplotlib.pyplot as plt
import networkx as nx
import pandas as pd
import seaborn as sns
import streamlit as st
from wordcloud import WordCloud
from preprocess import preprocess_text

st.set_page_config(page_title="Sentiment Dashboard", page_icon="📊", layout="wide")
ART = Path("artifacts")
ORDER = ["Negative", "Neutral", "Positive"]
COLORS = ["#c0392b", "#8a8f98", "#2e8b57"]

# Stop with a clear message if the notebook has not been run yet
if not (ART / "metrics.json").exists():
    st.error("Run the notebook first, then put the 'artifacts' folder next to this file.")
    st.stop()


@st.cache_resource
def load_model():
    return joblib.load(ART / "sentiment_pipeline.joblib")


def read(name):
    p = ART / name
    return pd.read_csv(p) if p.exists() else None


model = load_model()
metrics = json.load(open(ART / "metrics.json"))
id2label = {int(k): v for k, v in json.load(open(ART / "labels.json"))["id2label"].items()}

# ---------- Title and key numbers ----------
st.title("Social Media Sentiment Dashboard")
st.caption("Tweets -> Kafka stream -> Spark -> sentiment model -> dashboard")
c = st.columns(5)
c[0].metric("Posts analysed", f"{metrics['total_posts']:,}")
c[1].metric("Best classic model", metrics["best_model"])
c[2].metric("Accuracy", f"{metrics['accuracy']:.1%}")
c[3].metric("F1-score", f"{metrics['f1']:.1%}")
c[4].metric("LSTM accuracy", f"{metrics['lstm_accuracy']:.1%}")

tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(
    ["Overview", "Try a post", "Trends", "Word cloud", "Hashtag network", "Live stream"])

# ---------- Tab 1: sentiment distribution, model comparison, confusion matrix ----------
with tab1:
    left, right = st.columns(2)
    counts = read("sentiment_counts.csv")
    fig, ax = plt.subplots(figsize=(4.5, 4))
    ax.pie(counts["Count"], labels=counts["Sentiment"], colors=COLORS, autopct="%1.1f%%",
           wedgeprops={"width": 0.45, "edgecolor": "white"})
    ax.set_title("Sentiment distribution")
    left.pyplot(fig)
    plt.close(fig)
    right.subheader("Model comparison")
    right.dataframe(read("model_comparison.csv"), hide_index=True)
    cm = read("confusion_matrix.csv").set_index("Actual")
    fig, ax = plt.subplots(figsize=(4.5, 3.5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False, ax=ax)
    ax.set_title(f"Confusion matrix - {metrics['best_model']}")
    right.pyplot(fig)
    plt.close(fig)

# ---------- Tab 2: predict a new post ----------
with tab2:
    text = st.text_area("Type or paste a social media post", height=100,
                        value="Grateful for the nurses and doctors. Stay safe everyone!")
    if st.button("Predict sentiment", type="primary"):
        clean = preprocess_text(text)
        if not clean:
            st.warning("No meaningful words left after cleaning, so the prediction is unreliable.")
        proba = pd.Series(model.predict_proba([clean])[0], index=[id2label[int(k)] for k in model.classes_])[ORDER]
        st.subheader(f"Prediction: {proba.idxmax()}  ({proba.max():.1%} confident)")
        st.bar_chart(proba)
        st.caption(f"Text seen by the model: {clean}")

# ---------- Tab 3: history and 7-day forecast ----------
with tab3:
    trend = read("trend.csv")
    if trend is not None:
        wide = trend.pivot(index="date", columns="sentiment", values="percent")[ORDER]
        st.line_chart(wide, color=COLORS)
        st.caption("Daily share of posts (%). The last 7 days are the forecast.")
        st.dataframe(trend[trend["kind"] == "forecast"].pivot(index="date", columns="sentiment", values="percent").round(1))

# ---------- Tab 4: word cloud ----------
with tab4:
    words = read("word_freq.csv")
    pick = st.radio("Show words from", ["All"] + ORDER, horizontal=True)
    sub = words[words["sentiment"] == pick]
    cloud = WordCloud(width=900, height=450, background_color="white").generate_from_frequencies(dict(zip(sub["word"], sub["count"])))
    fig, ax = plt.subplots(figsize=(9, 4.5))
    ax.imshow(cloud)
    ax.axis("off")
    st.pyplot(fig)
    plt.close(fig)

# ---------- Tab 5: hashtag network ----------
with tab5:
    edges, nodes = read("network_edges.csv"), read("network_metrics.csv")
    G = nx.Graph()
    G.add_weighted_edges_from(edges.itertuples(index=False, name=None))
    pr = nodes.set_index("node")["pagerank"]
    fig, ax = plt.subplots(figsize=(9, 6))
    pos = nx.spring_layout(G, seed=42)
    nx.draw_networkx_edges(G, pos, alpha=0.25, ax=ax)
    nx.draw_networkx_nodes(G, pos, node_size=[300 + 9000 * pr[n] for n in G.nodes()], node_color="#5b7db1", ax=ax)
    nx.draw_networkx_labels(G, pos, font_size=8, ax=ax)
    ax.axis("off")
    st.pyplot(fig)
    plt.close(fig)
    st.dataframe(nodes.head(10)[["node", "frequency", "degree_centrality", "pagerank"]], hide_index=True)

# ---------- Tab 6: Kafka streaming results ----------
with tab6:
    stream = read("streaming_results.csv")
    if stream is not None:
        st.metric("Streaming accuracy", f"{metrics['stream_accuracy']:.1%}")
        st.area_chart(stream[ORDER].cumsum(), color=COLORS)
        st.caption("Cumulative posts per predicted sentiment, micro-batch by micro-batch.")
